define(['ROT'],
	function (ROT) {
	'use strict';

	var Display = {

		draw: function ($map, $actors)
		{
			var cells = $map.getCells();
			var ROTdisplay = new ROT.Display();
			document.body.appendChild(ROTdisplay.getContainer());

			for (var key in cells)
			{
				var parts = key.split(',');
				var x = parseInt(parts[0]);
				var y = parseInt(parts[1]);

				var toDraw = 0;
				switch (cells[key].getType())
				{
					case 1:
						toDraw = ' ';
						break;
					case '*':
						toDraw = 'b';
						break;
					case 0:
						toDraw = '.';
						break;
					default:
						toDraw = cells[key].getType();
						break;
				}
				ROTdisplay.draw(x, y, toDraw);
			}

			var visiData = $map.getVisibilityData($actors[0].x, $actors[0].y);
			for (var i = 0, visiCellsData = visiData.visibleCells; i < visiCellsData.length; i += 1)
			{
				var currCell = visiCellsData[i];
				var ch = (currCell.r ? '' : '@');
				var color = $map.getCells()[currCell.x + ',' + currCell.y].lightPasses() ? '#aa0': '#660';
				ROTdisplay.draw(currCell.x, currCell.y, ch, '#fff', color);
			}
			ROTdisplay.draw(visiData.lastSeeThrough.x, visiData.lastSeeThrough.y, 'x', '#fff', '#ff0000');
		}
		
	};

	return Display;

});