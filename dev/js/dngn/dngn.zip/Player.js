define(['dngn/Actor'],
	function (Actor) {
	'use strict';

	return {
		init: function ($engine, $map)
		{
			this.engine = $engine;
			this.map = $map;
			this.loop = 0;
			this.x = 0;
			this.y = 0;
		},
		act: function ()
		{
			this.loop += 1;
			if (this.loop > 4) { this.engine.lock(); }
			else
			{
				this.engine.lock();
				console.log('See that ? Acting.');
				setTimeout(this.engine.unlock, 2000);
			}

			// if (this.loop > 4) { setTimeout(this.engine.lock, 1000); this.engine.lock(); }
			// else
			// {
			// 	console.log('acting !');
			// 	this.engine.lock();
			// 	setTimeout(this.engine.unlock, 500);
			// }
		}
	};
});