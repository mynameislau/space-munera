define([],
	function () {
	'use strict';

	return {
		init: function ($type)
		{
			this.x = 0;
			this.y = 0;
			this.type = $type;
		},
		getType: function ($type)
		{
			return this.type;
		},
		setType: function ($type)
		{
			this.type = $type;
		},
		lightPasses: function ()
		{
			return this.type !== 1;
		},
		isWalkable: function ()
		{
			return this.type === 0;
		}
	};
});