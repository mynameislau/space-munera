define(['ROT', 'dngn/Cell'],
	function (ROT, Cell) {
	'use strict';

	var Map = {

		generate: function () {

			this.cells = {};
			this.freeCells = undefined;
			this.cellsVisibleData = {};

			var digger = new ROT.Map.Digger();

			var digCallback = function (x, y, type) {
				var key = x + ',' + y;
				var currCel = this.cells[key] = Object.create(Cell);
				currCel.init(type);
			};
			digger.create(digCallback.bind(this));
			//this.generateBoxes();
		},
		placePlayer: function ($player)
		{
			//random position for player
			console.log(this.getFreeCells());
			var key = this.getFreeCells().splice(0, 1)[0];
			$player.x = Number(key.split(',')[0]);
			$player.y = Number(key.split(',')[1]);
			$player.key = key;
		},
		replaceCell: function ($oldKey, $newKey)
		{
			return undefined;
		},
		getCells: function ()
		{
			return this.cells;
		},
		getFreeCells: function ()
		{
			if (this.freeCells) { return this.freeCells; }
			
			this.freeCells = [];
			for (var key in this.cells)
			{
				if (this.cells[key].isWalkable())
				{
					this.freeCells.push(key);
				}
			}
			return this.freeCells;
		},
		generateBoxes: function ()
		{
			for (var i = 0; i < 10; i += 1)
			{
				var index = Math.floor(ROT.RNG.getUniform() * this.freeCells.length);
				var key = this.freeCells.splice(index, 1)[0];
				this.cells[key].setType('*');
			}
		},
		getVisibilityData: function ($xPos, $yPos)
		{
			var cached = this.cellsVisibleData[$xPos + ',' + $yPos];
			if (cached) { return cached; }

			var cells = this.cells;
			/* input callback */
			var lightPasses = function (x, y) {
				var key = x + ',' + y;
				//if not a wall then light passes
				if (key in cells) { return (cells[key].lightPasses()); }
				return false;
			};

			var fov = new ROT.FOV.PreciseShadowcasting(lightPasses.bind(this));

			var lastSeeThrough = {};
			var visibleCells = [];
			fov.compute($xPos, $yPos, 10, function (x, y, r, visibility) {
				/*var xDist = Math.abs(stp.x - x);
				var yDist = Math.abs(stp.y - y);
				var hyp = Math.sqrt(Math.pow(xDist, 2), Math.pow(yDist, 2));*/
				var key = x + ',' + y;
				visibleCells.push({ x: x, y: y, r: r, visibility: visibility });
				if (lightPasses(x, y))
				{
					lastSeeThrough.x = x;
					lastSeeThrough.y = y;
				}
			});

			var toReturn = this.cellsVisibleData[$xPos + ',' + $yPos] = { visibleCells: visibleCells, lastSeeThrough: lastSeeThrough };
			return toReturn;
		}
		
	};

	return Map;

});